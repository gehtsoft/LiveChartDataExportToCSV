# LiveChartDataExportToCSV

## Building from sources

* Move source folder from Git repository to folder inside folder with installed ForexConnectAPI
* Build source\LiveChartDataExportToCSV.csproj with Visual Studio version 2015 or later
* Copy LiveChartDataExportToCSV.exe file from source\bin\\%PLATFORM%\\%TARGET%\\ to folder with installed ForexConnectAPI (%PLATFORM% is ether "x86" or "x64" and %TARGET% is "Release" or "Debug" depending on Visual Studio build type)

